function toggleMenu() {
    document.querySelector("nav").classList.toggle("show-menu");
}

function createFloatingBalls(num) {
    const container = document.querySelector(".background-balls");
    for (let i = 0; i < num; i++) {
        let ball = document.createElement("div");
        ball.classList.add("ball");
        ball.style.left = Math.random() * 100 + "vw";
        ball.style.top = Math.random() * 100 + "vh";
        ball.style.animationDuration = (Math.random() * 5 + 3) + "s";
        container.appendChild(ball);
    }
}
createFloatingBalls(15);